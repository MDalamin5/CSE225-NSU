#include <iostream>
using namespace std;

class Box{

private:
    int length, width, height;

public:
    Box(int, int, int);
    int getVolume();


};
