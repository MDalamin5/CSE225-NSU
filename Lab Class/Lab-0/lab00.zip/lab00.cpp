#include <iostream>
using namespace std;

int main()
{
    /*
    int prime, count = 0;

    cout << "Please enter a number to check whether it's a prime or not: ";
    cout << endl;

    cin >> prime;

    for(int i=2; i<=prime; i++)
    {
        if(prime % i == 0)
            count++;
    }

    if(count == 1)
        cout << prime << " is a prime number!" << endl;
    else
        cout << prime << " is not a prime number!" << endl;

    */



}
